import image from  "./image/icon.svg"

const assets = {
  image
}

export default assets;