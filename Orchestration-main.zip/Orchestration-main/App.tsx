import React from 'react';
import './App.css';
import SignUpForm from './components/SignUpForm';

const App: React.FC = () => (
  <div className="App">
    <SignUpForm />
  </div>
);

export default App;
