import infopng from '../assets/image/info.png';

const info = {
  infopng,
} 

export default info;