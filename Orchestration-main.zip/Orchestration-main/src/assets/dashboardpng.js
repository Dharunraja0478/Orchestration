import  dashboard from "../assets/image/dashboard.png";

const dashboardpng = {
  dashboard
}  

export default dashboardpng;