import filterpng from '../assets/image/filter.png'; 

const filter= 
{
  filterpng,
} 

export default filter;