import executepng from '../assets/image/execution.png'; 

const execution = {
  executepng,
} 

export default execution;