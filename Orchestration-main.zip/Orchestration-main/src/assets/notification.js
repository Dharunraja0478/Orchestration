import notificationpng from '../assets/image/notification.png';

const notification = {
  notificationpng,
} 

export default notification;