import workflowimg from '../assets/image/workflow.png'; 

const workflow = 
{
  workflowimg
} 

export default workflow;