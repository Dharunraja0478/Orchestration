import morepng from '../assets/image/more.png';

const more={
  morepng,
} 

export default more;