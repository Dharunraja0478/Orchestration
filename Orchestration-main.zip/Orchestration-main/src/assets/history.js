import historypng from '../assets/image/history.png'; 

const history = {
  historypng,
} 

export default history;