import cart from '../assets/image/cart.png';

const cartpng = 
{
  cart
} 

export default cartpng;