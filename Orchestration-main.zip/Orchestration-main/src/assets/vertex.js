import  vertexpng from '../assets/image/carbon.png';

const vertex = 
{
  vertexpng,
}  

export default vertex;