import arrowpng from '../assets/image/arrow.png';

const arrow = {
  arrowpng,
} 

export default arrow;