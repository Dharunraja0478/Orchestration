import rightarrowpng from '../assets/image/rightarrow.png';

const rightarrow= {
  rightarrowpng,
} 

export default rightarrow;