import createpin from '../assets/image/createpin.png'; 

const createpinpng = 
{
  createpin
} 

export default createpinpng;