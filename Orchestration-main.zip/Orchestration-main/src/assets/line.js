import linepng from '../assets/image/Line.png';

const line= {
  linepng,
} 

export default line;